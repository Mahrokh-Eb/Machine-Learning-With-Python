'''
Programmer: Mahrokh Ebrahimi
Discroption: Declare two variables and assign values to these two variables
and then display the product of these two values.
Date:6/28/2020

'''

x = 10
y = 1

print (x * y)