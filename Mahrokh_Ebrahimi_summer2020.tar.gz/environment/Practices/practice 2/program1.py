'''
Programmer: Mahrokh Ebrahimi
Discroption: Have a user to enter a number. Write some conditional statement to check whether the number entered by the user is even or odd.
Date:6/28/2020

'''
num = int(input('enter a number'))

if (num % 2 == 0):
    print('it is even!')
    
else:
    print ('it is odd!')

