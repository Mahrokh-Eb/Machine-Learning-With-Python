'''
Programmer: Mahrokh Ebrahimi
Discroption: Write a program that asks for the names of three runners and the time it took each of them to ﬁnish a race. The program should display who came in ﬁrst, second, and third place.
Think about how many test cases are needed to verify that your problem works correctly.
Date:6/28/2020

'''

runner1 = input('runner 1?')
time1 = int(input('time?'))
runner2 = input('runner 2?')
time2 = int(input('time?'))
runner3 = input('runner 3?')
time3 = int(input('time?'))